package com.example.calango.model.enums;

public enum Dificuldade {

	Fácil,
	Mediano,
	Difícil;
}
