package com.example.calango.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.calango.model.Questionario;

public interface QuestionarioRepository extends JpaRepository<Questionario, Integer>{

}
