package com.example.calango.model.enums;

public enum Bloom {
	
	Avaliação,
	Síntese,
	Analise,
	Aplicação,
	Compreensão,
	Conhecimento;
}
